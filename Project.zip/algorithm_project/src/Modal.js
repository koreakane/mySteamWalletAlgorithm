import React from "react";
import "./App.css";

function Modal({ show }) {
  return (
    <>
      <div className={show ? "overlay" : "hide"} />
      <div className={show ? "modal" : "hide"}>
        <h1>추가 리스트를 가져오는 중...</h1>
        <h3>당신의 지갑을 털기위해 크롤링중입니다...</h3>
        <img src={require("./assets/steam.gif")}></img>
      </div>
    </>
  );
}

export default Modal;

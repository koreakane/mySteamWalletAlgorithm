import React, { useState, useEffect } from "react";
import "./App.css";
import Modal from "./Modal";
import Button from "@material-ui/core/Button";
import ButtonGroup from "@material-ui/core/ButtonGroup";
import TextField from "@material-ui/core/TextField";
import { makeStyles } from "@material-ui/core/styles";
import Typography from "@material-ui/core/Typography";
import Link from "@material-ui/core/Link";

import Table from "@material-ui/core/Table";
import TableBody from "@material-ui/core/TableBody";
import TableCell from "@material-ui/core/TableCell";
import TableHead from "@material-ui/core/TableHead";
import TableRow from "@material-ui/core/TableRow";
import Paper from "@material-ui/core/Paper";

const useStyles = makeStyles({
  root: {
    width: "100%",
    overflowX: "auto"
  },
  table: {
    minWidth: 650
  },
  redtable: {
    backgroundColor: "lightgrey"
  }
});

function App() {
  const [show, setShow] = useState(false);
  const [data, setData] = useState([]);
  const [selectedData, setSelectedData] = useState([]);
  const [max, setMax] = useState("");
  const [rate, setRate] = useState(0);
  const [page, setPage] = useState(1);

  const classes = useStyles();

  const gKnapsack = (data, max) => {
    setShow(true);
    if (max <= 100) {
      alert("적절한 금액을 입력해주세요!");
      return;
    }
    console.log(selectedData);
    var funcmax = Number(max) * 10;
    setRate(0);
    setSelectedData([]);
    var k = 0;
    var rating = 0;
    var selection = [];
    while (funcmax > 0 && k < data.length) {
      console.log(data[k]);
      console.log(funcmax);
      if (Number(data[k].price) < funcmax) {
        rating += Number(data[k].rating);
        funcmax -= Number(data[k].price);
        console.log(data[k].index);
        selection = selection.concat(data[k]);
        console.log(selection);
      }
      k++;
    }
    setRate(rating);
    setSelectedData(selection);
    console.log(selectedData);
    setShow(false);
  };

  const dKnapsack = (data, max) => {
    setShow(true);

    var m = [];
    for (var i = 0; i <= data.length; i++) {
      m[i] = [];
      for (var j = 0; j <= max; j += 100) {
        m[i][j] = { p: 0, list: [] };
      }
    }
    for (i = 0; i < data.length + 1; i++) {
      for (j = 0; j <= max; j += 1000) {
        if (i === 0 || j === 0) {
          m[i][j].p = 0;
        } else if (Number(data[i - 1].price) > j) {
          m[i][j].p = m[i - 1][j].p;
          m[i][j].list = [...m[i - 1][j].list];
        } else {
          // if (i === data.length) {
          //   selection = selection.concat(data[i]);
          // }
          m[i][j].p = Math.max(
            m[i - 1][j].p,
            m[i - 1][j - Number(data[i - 1].price)].p +
              Number(
                (1 + data[i - 1].price_discount / 100) * data[i - 1].rating
              )
          );
          if (
            m[i - 1][j].p <
            m[i - 1][j - Number(data[i - 1].price)].p +
              Number(
                (1 + data[i - 1].price_discount / 100) * data[i - 1].rating
              )
          ) {
            m[i][j].list = [
              ...m[i - 1][j - Number(data[i - 1].price)].list,
              i
            ];
          } else {
            m[i][j].list = [...m[i - 1][j].list];
          }
        }
      }
    }
    console.log(m[data.length][max].p);
    console.log(m[data.length][max].list);

    let selection = data.filter((val, index) =>
      m[data.length][max].list.includes(index)
    );
    console.log(selection);
    var sum = 0;
    selection.forEach(element => {
      sum += element.price;
    });
    console.log(sum/10);
    setRate(m[data.length][max].p);
    setSelectedData(selection);
    setShow(false);
  };

  const callAPI = async () => {
    try {
      await setShow(true);
      const response = await fetch(
        "http://localhost:9000/testAPI/data/" + page
      );
      const responsed = await response.json();
      sorting([...data].concat(responsed), "rating");
      // await setData();
      setPage(page + 1);
      setShow(false);
    } catch (e) {
      console.log(e);
    }
  };

  const sorting = (sortingData, sortingField) => {
    // console.log(sortingData);
    sortingData.sort(function(a, b) {
      return b[sortingField] - a[sortingField];
    });
    // console.log(sortingData);
    setData(sortingData);
  };

  const clearInput = () => {
    setSelectedData([]);
    setMax("");
  };

  const handleKeyDown = e => {
    if (e.key === "Enter") {
      gKnapsack(data, max);
    }
  };

  useEffect(() => {
    callAPI();
  }, []);

  // useEffect(() => {
  //   console.log(data);
  // }, [data]);

  return (
    <div className="App">
      <Modal show={show} />
      <Typography variant="h3" gutterBottom>
        스팀 할인 월렛 계산기!
      </Typography>
      <Typography variant="h5" gutterBottom>
        당신이 보유한 금액을 입력하세요.
      </Typography>
      <div
        style={{
          display: "flex",
          flexDirection: "row",
          alignItems: "center",
          justifyContent: "space-between"
        }}
      >
        <TextField
          value={max}
          autoFocus={true}
          onKeyDown={e => handleKeyDown(e)}
          onChange={e => setMax(e.target.value)}
          placeholder="현재 월렛..."
          // id="standard-number"
          label="Number"
          type="number"
          className="maxNum"
          margin="normal"
        />
        <ButtonGroup variant="contained" color="primary" size="large">
          <Button onClick={() => gKnapsack(data, max)}>
            Greedy Aproach!
          </Button>
          <Button onClick={() => dKnapsack(data, max * 10)}>
            Dynamic Aproach!
          </Button>
          <Button onClick={() => clearInput()}>초기화!</Button>
          <Button onClick={() => callAPI()}>+250</Button>
        </ButtonGroup>
      </div>
      <h4>레이팅 : {rate}</h4>
      <Paper className={classes.root}>
        <Table className={classes.table} aria-label="simple table">
          <TableHead>
            <TableRow>
              <TableCell>Index</TableCell>
              <TableCell align="left">Game</TableCell>
              <TableCell align="left">url</TableCell>
              <TableCell align="left">Price Discount&nbsp;(%)</TableCell>
              <TableCell align="right">Price&nbsp;(won)</TableCell>
              <TableCell align="right">rating&nbsp;(%)</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {selectedData.map((data, index) => (
              <TableRow key={data.index}>
                <TableCell className={classes.redtable} align="center">
                  {index}
                </TableCell>
                <TableCell className={classes.redtable} align="left">
                  {data.name}
                </TableCell>
                <TableCell className={classes.redtable} align="left">
                  <Link href={data.url}>Link</Link>
                </TableCell>
                <TableCell className={classes.redtable} align="center">
                  {data.price_discount}
                </TableCell>
                <TableCell className={classes.redtable} align="center">
                  {data.price / 10}
                </TableCell>
                <TableCell className={classes.redtable} align="center">
                  {data.rating}
                </TableCell>
              </TableRow>
            ))}
            {selectedData === [] ? (
              <></>
            ) : (
              data.map((data, index) => (
                <TableRow key={data.index}>
                  <TableCell align="center">{index}</TableCell>
                  <TableCell align="left">{data.name}</TableCell>
                  <TableCell align="left">
                    <Link href={data.url}>Link</Link>
                  </TableCell>
                  <TableCell align="center">
                    {data.price_discount}
                  </TableCell>
                  <TableCell align="center">{data.price / 10}</TableCell>
                  <TableCell align="center">{data.rating}</TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </Paper>
    </div>
  );
}

export default App;

var express = require("express");
var router = express.Router();
const axios = require("axios");
const cheerio = require("cheerio");
const log = console.log;
var http = require("http");
var data = [];

const getFunction = async () => {
  try {
    const html = await axios.get(
      "https://steamdb.info/sales/?max_price=50000&min_discount=40&min_rating=60&cc=kr"
    );

    let ulList = [];
    const $ = cheerio.load(html.data);
    const $bodyList = $("table.table-sales tbody").children("tr");
    // console.log($bodyList.html())

    $bodyList.each(function(i, elem) {
      //   console.log("index" + i) + "\n";
      //   console.log($(this).html());
      //   console.log(
      //     "____________________________________________________________________________________________________"
      //   );
      ulList[i] = {
        index: i,
        name: $(this)
          .find("td.applogo")
          .next()
          .find("a")
          .text(),
        url: $(this)
          .eq(0)
          .find("a")
          .attr("href"),
        //   image_url: $(this)
        //     .find("td.applogo a img")
        //     .attr("src"),
        price_discount: $(this)
          .find("td.price-discount")
          .attr("data-sort"),
        price:
          Number(
            $(this)
              .find("td.price-discount")
              .next()
              .attr("data-sort")
          ) / 10,
        rating: $(this)
          .find("td.price-discount")
          .next()
          .next()
          .attr("data-sort")
      };
    });
    // console.log(ulList);

    ulList = ulList.filter(function(arr) {
      return (
        arr.price !== undefined &&
        arr.price !== 0 &&
        arr.rating !== undefined
      );
    });
    data = ulList;
    return ulList;
  } catch (error) {
    console.error(error);
  }
};

router.get("/data/:list", async function(req, res, next) {
  const rawdata = await getFunction();
  const list = req.params.list;
  res.send(rawdata.slice((list - 1) * 250, list * 250));
});
//   .catch(e => {
//     console.log(e);
//   });

module.exports = router;
